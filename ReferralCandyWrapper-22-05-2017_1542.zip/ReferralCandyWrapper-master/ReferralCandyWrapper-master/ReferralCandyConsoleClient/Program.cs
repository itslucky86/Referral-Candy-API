﻿using ReferralCandyWrapper;
using ReferralCandyWrapper.Messages;
using System;

namespace ReferralCandyConsoleClient
{
    class Program
    {
        static void Main(string[] args)
        {
            IReferralCandy referralCandy = new ReferralCandy("hbnwiqoy590n4aw4durns06rs", "9d2e99fb5febbfafd4bc56ace31e2ceb");

            Console.WriteLine("Verify...");

            var response = referralCandy.Verify(new VerifyRequest());

            Console.WriteLine("HTTP Code: {0}", response.HttpCode);
            Console.WriteLine("Message: {0}", response.Message);


            Console.WriteLine("Purchase...");

            var purchaseRequest = new PurchaseRequest
            {
                FirstName = "usman",
                LastName = "chohan",
                Email = "info@usmanchohan.co.uk",
                CurrencyCode = "GBP",
               // BrowserIP = "172.0.0.1",
               // UserAgent = "Chrome",
                OrderDateTime = DateTime.Now,
                InvoiceAmount = 14.99M,
                ExternalReferenceID = "DWBSFKN"
            };

            response = referralCandy.Purchase(purchaseRequest);

            Console.WriteLine("HTTP Code: {0}", response.HttpCode);
            Console.WriteLine("Message: {0}", response.Message);
            Console.WriteLine("Referral Corner URL: {0}", response.ReferralCornerUrl);

            Console.ReadLine();
        }
    }
}
